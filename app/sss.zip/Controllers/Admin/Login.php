<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;


class Login extends BaseController 
{

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger) 
    {
        parent::initController($request, $response, $logger);
        $this->Model_login = new \App\Models\Admin\Model_login();
    }

    public function index()
    {
        $error = '';

        $data['setting'] = $this->Model_login->get_setting_data();

        $logged_in = $this->session->get('logged_in');
        if($logged_in)
        {
            redirect(base_url().'admin/dashboard');
        }

        if(isset($_POST['form1'])) {

            // Getting the form data
            $email = $this->request->getPost('email',true);
            $password = $this->request->getPost('password',true);

            // Checking the email address
            $un = $this->Model_login->check_email($email);

            if(!$un) {
                $error = 'Email address is wrong!';
                $this->session->setFlashdata('error',$error);
                redirect(base_url().'admin');

            } else {

                // When email found, checking the password
                $pw = $this->Model_login->check_password($email,$password);

                if(!$pw) {
                    
                    $error = 'Password is wrong!';
                    $this->session->setFlashdata('error',$error);
                    redirect(base_url().'admin');

                } else {

                    // When email and password both are correct
                    $array = array(
                        'id' => $pw['id'],
                        'email' => $pw['email'],
                        'password' => $pw['password'],
                        'photo' => $pw['photo'],
                        'role' => $pw['role'],
                        'status' => $pw['status'],
                        'logged_in' => true
                    );
                    $this->session->set($array);
                    redirect(base_url().'admin/dashboard');
                }
            }
        } else {
            echo view('admin/view_login',$data);    
        }
        
    }

    function logout() {
        $this->session->destroy();
        redirect(base_url().'admin');
    }
}
