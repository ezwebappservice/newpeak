<?php
namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;



class Menu extends BaseController 
{
	public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger) 
	{
        parent::initController($request, $response, $logger);
        $this->Model_common = new \App\Models\Admin\Model_common();
        $this->Model_menu = new \App\Models\Admin\Model_menu();
    }

	public function index()
	{       	
       	$data['setting'] = $this->Model_common->get_setting_data();
		$error = '';
		$success = '';

		if(isset($_POST['form1']))
		{

			if(PROJECT_MODE == 0) {
				$this->session->setFlashdata('error',PROJECT_NOTIFICATION);
				redirect($_SERVER['HTTP_REFERER']);
			}
			
			$arr1 = array();
			$arr2 = array();

			foreach($_POST['menu_id'] as $val) {
				$arr1[] = $val;
			}

			foreach($_POST['menu_status'] as $val) {
				$arr2[] = $val;
			}

			// Update the menu
			for($i=0;$i<count($arr1);$i++) {
				$form_data = array(
					'menu_status' => $arr2[$i]
	            );
	            $this->Model_menu->update($arr1[$i],$form_data);
			}
		
			$success = 'Menu is updated successfully';
		    
			$this->session->setFlashdata('success',$success);
			redirect(base_url().'admin/menu');
           
		} else {
			$data['all_menus'] = $this->Model_menu->show();
	       	echo view('admin/view_header',$data);
			echo view('admin/view_menu',$data);
			echo view('admin/view_footer');
		}

	}


}