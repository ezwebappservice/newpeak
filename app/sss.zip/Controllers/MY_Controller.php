<?php

namespace App\Controllers;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class MY_Controller extends BaseController
{
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.
        $this->Model_lang = new \App\Models\Model_lang();

        if (!isset($_SESSION['sess_lang_id'])) {
            $lang = $this->Model_lang->get_default_language_id();
            $_SESSION['sess_lang_id'] = $lang['lang_id'];
            $_SESSION['sess_layout_direction'] = $lang['layout_direction'];
        }

        $detail_arr = $this->Model_lang->get_detail_by_language_id($_SESSION['sess_lang_id']);
        foreach ($detail_arr as $row) {
            if (!defined($row['lang_string'])) {
                define($row['lang_string'], $row['lang_string_value']);
            }
        }
    }
}
