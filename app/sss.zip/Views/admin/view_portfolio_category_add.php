<?php
if(!$this->session->userdata('id')) {
	redirect(base_url().'admin/login');
}
?>

<section class="content-header">
	<div class="content-header-left">
		<h1>Add Portfolio Category</h1>
	</div>
	<div class="content-header-right">
		<a href="<?php echo base_url(); ?>admin/portfolio_category" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>


<section class="content">

	<div class="row">
		<div class="col-md-12">

			<?php
	        if(session()->getFlashdata('error')) {
	            ?>
	            <div class="callout callout-danger">
	                <p><?php echo session()->getFlashdata('error'); ?></p>
	            </div>
	            <?php
	        }
	        if(session()->getFlashdata('success')) {
	            ?>
	            <div class="callout callout-success">
	                <p><?php echo session()->getFlashdata('success'); ?></p>
	            </div>
	            <?php
	        }
	        ?>

			<?php echo form_open(base_url().'admin/portfolio_category/add',array('class' => 'form-horizontal')); ?>

				<div class="box box-info">
					<div class="box-body">
						<div class="form-group">
							<label for="" class="col-sm-2 control-label">Category Name <span>*</span></label>
							<div class="col-sm-4">
								<input type="text" class="form-control" name="category_name">
							</div>
						</div>
						<div class="form-group">
				            <label for="" class="col-sm-2 control-label">Status *</label>
				            <div class="col-sm-4">
				            	<select name="status" class="form-control select2">
				            		<option value="Active">Active</option>
				            		<option value="Inactive">Inactive</option>
				            	</select>
				            </div>
				        </div>
				        <div class="form-group">
							<label for="" class="col-sm-2 control-label">Language </label>
							<div class="col-sm-2">
								<select name="lang_id" class="form-control select2">
									<?php
									foreach($all_lang as $row)
									{
										?><option value="<?php echo $row['lang_id']; ?>"><?php echo $row['lang_name']; ?></option><?php
									}
									?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="col-sm-2 control-label"></label>
							<div class="col-sm-6">
								<button type="submit" class="btn btn-success pull-left" name="form1">Submit</button>
							</div>
						</div>
					</div>
				</div>

			<?php echo form_close(); ?>


		</div>
	</div>

</section>