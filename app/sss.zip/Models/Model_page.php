<?php
namespace App\Models;



class Model_page extends \App\Models\CI3Model 
{
    public function page_check($slug)
    {
        $this->db->select('*');
        $this->db->from('tbl_page_dynamic');
        $this->db->where('slug', $slug);
        $query = $this->db->get();
        return $query->getNumRows();
    }

    public function dynamic_page_by_slug($slug)
    {
        $this->db->select('*');
        $this->db->from('tbl_page_dynamic');
        $this->db->where('slug', $slug);
        $query = $this->db->get();
        return $query->getRowArray();
    }
}