<?php
namespace App\Models\Admin;



class Model_news extends \App\Models\CI3Model 
{

	function get_auto_increment_id()
    {
        $sql = "SHOW TABLE STATUS LIKE 'tbl_news'";
        $query = $this->db->query($sql);
        return $query->getResultArray();
    }

    function show() {
        $sql = "SELECT
                t1.news_id,
                t1.news_title,
                t1.news_content,
                t1.photo,
                t1.banner,
                t1.category_id,
                t1.lang_id,
                t2.category_id,
                t2.category_name,
                t3.lang_id,
                t3.lang_name
                FROM tbl_news t1
                JOIN tbl_category t2
                ON t1.category_id = t2.category_id
                JOIN tbl_lang t3
                ON t1.lang_id = t3.lang_id
                ORDER BY t1.news_id DESC";
        $query = $this->db->query($sql);
        return $query->getResultArray();
    }


    function add($data) {
        $this->db->table('tbl_news')->insert($data);
        return $this->db->insert_id();
    }

    function update($id,$data) {
        $this->db->where('news_id',$id);
        $this->db->table('tbl_news')->update($data);
    }

    function delete($id)
    {
        $this->db->where('news_id',$id);
        $this->db->table('tbl_news')->delete();
    }

    function getData($id)
    {
        $sql = 'SELECT * FROM tbl_news WHERE news_id=?';
        $query = $this->db->query($sql,array($id));
        return $query->getRowArray();
    }

    function get_category()
    {
        $sql = 'SELECT * FROM tbl_category ORDER BY category_name ASC';
        $query = $this->db->query($sql);
        return $query->getResultArray();
    }

    function news_check($id)
    {
        $sql = 'SELECT * FROM tbl_news WHERE news_id=?';
        $query = $this->db->query($sql,array($id));
        return $query->getRowArray();
    }
   
}