<?php
namespace App\Models\Admin;



class Model_reset_password extends \App\Models\CI3Model 
{

    public function get_setting_data()
    {
        $query = $this->db->query("SELECT * from tbl_settings WHERE id=1");
        return $query->getRowArray();
    }

    function check_url($email,$token) {
        $query = $this->db->query("SELECT * from tbl_user WHERE email=? AND token=?",array($email,$token));
        return $query->getRowArray();
    }

    function update($email,$data) {
        $this->db->where('email',$email);
        $this->db->table('tbl_user')->update($data);
    }
}