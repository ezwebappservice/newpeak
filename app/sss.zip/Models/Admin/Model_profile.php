<?php
namespace App\Models\Admin;




class Model_profile extends \App\Models\CI3Model 
{

    function update($data) {
        $this->db->where('id',1);
        $this->db->table('tbl_user')->update($data);
    }
    
}