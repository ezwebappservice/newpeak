<?php
namespace App\Models;



class Model_contact extends \App\Models\CI3Model 
{
    public function all_testimonial()
    {
        $query = $this->db->query("SELECT * FROM tbl_testimonial ORDER BY id ASC");
        return $query->getResultArray();
    }

    public function check_captcha()
    {
    	$query = $this->db->query("SELECT * FROM tbl_setting_captcha WHERE id=?",[1]);
        return $query->getRowArray();
    }

    public function total_captcha()
    {
    	$query = $this->db->query("SELECT * FROM tbl_captcha");
        return $query->getNumRows();
    }

    public function get_particular_captcha($id)
    {
    	$query = $this->db->query("SELECT * FROM tbl_captcha WHERE captcha_id=?",[$id]);
        return $query->getRowArray();
    }
}